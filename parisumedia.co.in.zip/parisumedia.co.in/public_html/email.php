
<?php
session_start();
// For Sending Sms
//require_once dirname(__FILE__) . '\captcha\securimage.php';

//$securimage = new Securimage();
			$captcha = @$_REQUEST['ct_captcha']; // the user's entry for the captcha code
           if(isset($_POST["captcha"])&&$_POST["captcha"]!=""&&$_SESSION["code"]==$_POST["captcha"]) {
				try{
                  
                  require 'phpmailer/PHPMailerAutoload.php';

$mail = new PHPMailer;
$mail->isSMTP();
$mail->Debugoutput = 'html';
$mail->Host = "mail.parisumedia.co.in";
$mail->Port = 587;
$mail->SMTPAuth = true;
$mail->SMTPSecure = 'tls';
$mail->Username = "mailenquiry@parisumedia.co.in";
$mail->Password = "KeytUMKruuMgPGy94aKE";
$mail->setFrom('mailenquiry@parisumedia.co.in', 'Parisu Media Enquiry');
$mail->addReplyTo('super7tnj@gmail.com', 'Parisu Media Enquiry');
$mail->addAddress('hello@parisumedia.co.in', 'Parisumedia'); //CHANGE THIS

$recipients = array(
   'super7tnj@gmail.com', //CHANGE THIS


);
foreach($recipients as $email)
{
   $mail->AddCC($email);
}

$mail->Subject = 'Parisu Media'; //CHANGE THIS
$body = "
<div style='background: linear-gradient(45deg, #4158d0, #c850c0); padding: 30px; font-family:Trebuchet MS;', align='center'>
<table width='80%;' style='border: 2px solid #fff; border-radius: 10px; background-color: #fff; ' >
	                        
							 <tr style='height: 50px; background: #36304a; font-size: 24px; color: #fff; border-radius: 10px;' >
							    <th colspan='2' align='center' valign='middle' >ENQUIRY FROM WEBSITE</th>
							 </tr>
							 
<tr style='background: #fff; font-size: 16px; color: #000;' >
<td style='padding: 20px; font-family:Trebuchet MS;' >Name : </td>
<td style='padding: 20px; font-family:Trebuchet MS;' >".$_REQUEST['name']."</td>
							 </tr>
							 
<tr style='background: #f5f5f5; font-size: 16px; color: #000;' >
<td style='padding: 20px; font-family:Trebuchet MS;' >Email : </td>
<td style='padding: 20px; font-family:Trebuchet MS;' >".$_REQUEST['email']."</td>
							 </tr>

<tr style='background: #fff; font-size: 16px; color: #000;' >
<td style='padding: 20px; font-family:Trebuchet MS;' >Number:</td>
<td style='padding: 20px; font-family:Trebuchet MS;' >".$_REQUEST['mobile']."</td>
							 </tr>
							 
				 
							 						 
<tr style='background: #fff; font-size: 16px; color: #000;' >
<td style='padding: 20px; font-family:Trebuchet MS;' >Description:</td>
<td style='padding: 20px; font-family:Trebuchet MS;' >".$_REQUEST['select1']." ".$_REQUEST['interstedin']."</td>
							 </tr>
                             
                             
							 
  <td colspan='2' align='center' valign='middle'>&nbsp;</td>
</tr>						 
							 
	                     </table></div>";
$mail->msgHTML($body);
 $mail->send();                 
            	$gatewayURL = 'https://www.smsintegra.net/api/smsapi.aspx?';
				$request = 'uid=AMSONWEBZ';
				$request .= '&pwd=amsonamson';
				$request .= '&mobile=9788524796';
				$request .= '&type=0';
				$request .= '&msg='.urlencode('C.Id: 1234,Got Enquiry from website Parisumedia : Name: .'.$_REQUEST['name'].', Email: '.$_REQUEST['email'].', Mobile: +91'.$_REQUEST['mobile'].'. Interested in - '.$_REQUEST['select1'].'. -Amson Marketing Consultants');                             
                $request .= '&sid='.urlencode('AMSONW');
				$request .= '&dtTimeNow='.$dtTimeNow.'&entityid=1601100000000004361&tempid=1607100000000093595';
				$url =  $gatewayURL . $request; 
				$url = preg_replace("/ /", "%20", $url);    
				$parse_url=file($url);
				echo $parse_url[0];				 
				
				$gatewayURL = 'https://www.smsintegra.net/api/smsapi.aspx?';
				$request = 'uid=AMSONWEBZ';
				$request .= '&pwd=amsonamson';
				$request .= '&mobile= +91'.$_REQUEST['mobile'];
				$request .= '&type=0';
				$request .= '&msg='.urlencode('Hi '.$_REQUEST['name'].',C.Id: 1234, Your Enquiry has been sent to Parisumedia - Amson Marketing Consultants');
				$request .= '&sid='.urlencode('AMSONW');
				$request .= '&dtTimeNow='.$dtTimeNow.'&entityid=1601100000000004361&tempid=1607100000000093593';
				$url =  $gatewayURL . $request; 
				$url = preg_replace("/ /", "%20", $url);    
				$parse_url=file($url);
				echo $parse_url[0];
				header('Location: index.html');   
				}
				catch(Exception $e)
				{
					echo 'Message:' .$e->getMessage();
				}	                      
            } else{
		die("The Code You have entered is incorrect ");	
	    }
