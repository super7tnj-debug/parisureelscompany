<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head> 

<!-- Favicon --> 

<div style=position:absolute;left:-4000px xmlns:v=http://rdf.data-vocabulary.org/#>
<span typeof=v:Breadcrumb><a href=http://www.eswartraders.com rel=v:url property=v:title>  </a> &lsaquo; </span>
<span typeof=v:Breadcrumb><a href=http://amsonwebz.com/services.html rel=v:url property=v:title>No.&#10102;  </a> &rsaquo; </span>
</div>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


<script language="javascript"> 
function cnum()
{
s=document.form.name.value
s=s.substring(s.length-1);

if(s=="1" || s=="2" || s=="3" || s=="4" || s=="5" || s=="6" || s=="7" || s=="8" || s=="9" || s=="0" || s=="`" || s=="~" || s=="@" || s=="#" || s=="$" || s=="%" || s=="^" || s=="&" || s=="*" || s=="(" || s==")" || s=="[" || s=="]" || s=="{" || s=="}" || s=="|" || s==" \ " || s=="/" || s=="<" || s==">" || s=="?" || s=="!")
	{
	
		alert("Numerical Character and Special Characters Not Allowed");
		document.form.name.value="";
		document.form.name.focus();
		return false;
	}
	return true;
}
function cnum1()
{
s=document.form.companyname.value
s=s.substring(s.length-1);

if(s=="1" || s=="2" || s=="3" || s=="4" || s=="5" || s=="6" || s=="7" || s=="8" || s=="9" || s=="0" || s=="`" || s=="~" || s=="@" || s=="#" || s=="$" || s=="%" || s=="^" || s=="&" || s=="*" || s=="(" || s==")" || s=="[" || s=="]" || s=="{" || s=="}" || s=="|" || s==" \ " || s=="/" || s=="<" || s==">" || s=="?" || s=="!" )
	{
	
		alert("Numerical Character and Special Characters Not Allowed");
		document.form.companyname.value="";
		document.form.companyname.focus();
		return false;
	}
	return true;
}
function cnum2()
{
s=document.form.city.value
s=s.substring(s.length-1);

if(s=="1" || s=="2" || s=="3" || s=="4" || s=="5" || s=="6" || s=="7" || s=="8" || s=="9" || s=="0" || s=="`" || s=="~" || s=="@" || s=="#" || s=="$" || s=="%" || s=="^" || s=="&" || s=="*" || s=="(" || s==")" || s=="[" || s=="]" || s=="{" || s=="}" || s=="|" || s==" \ " || s=="/" || s=="<" || s==">" || s=="?" || s=="!" )
	{
	
		alert("Numerical Character and Special Characters Not Allowed");
		document.form.city.value="";
		document.form.city.focus();
		return false;
	}
	return true;
}
function cnum3()
{
s=document.form.state.value
s=s.substring(s.length-1);

if(s=="1" || s=="2" || s=="3" || s=="4" || s=="5" || s=="6" || s=="7" || s=="8" || s=="9" || s=="0" || s=="`" || s=="~" || s=="@" || s=="#" || s=="$" || s=="%" || s=="^" || s=="&" || s=="*" || s=="(" || s==")" || s=="[" || s=="]" || s=="{" || s=="}" || s=="|" || s==" \ " || s=="/" || s=="<" || s==">" || s=="?" || s=="!" )
	{
	
		alert("Numerical Character and Special Characters Not Allowed");
		document.form.state.value="";
		document.form.state.focus();
		return false;
	}
	return true;
}
function cnum4()
{
s=document.form.phone.value
s=s.substring(s.length-1);

if(s=="A" || s=="B" || s=="C" || s=="D" || s=="E" || s=="F" || s=="G" || s=="H" || s=="I" || s=="J" || s=="K" || s=="L" || s=="M" || s=="N" || s=="O" || s=="P" || s=="Q" || s=="R" || s=="S" || s=="T" || s=="U" || s=="V" || s=="W" || s=="X" || s=="Y" || s=="Z" || s=="a" || s=="b" || s=="c" || s=="d" || s=="e" || s=="f" || s=="g" || s=="h" || s=="i" || s=="j" || s=="k" || s=="l" || s=="m" || s=="n" || s=="o" || s=="p" || s=="q" || s=="r" || s=="s" || s=="t" || s=="u" || s=="v" || s=="w" || s=="x" || s=="y" || s=="z"|| s==" " || s=="`" || s=="~" || s=="@" || s=="#" || s=="$" || s=="%" || s=="^" || s=="&" || s=="*" || s=="(" || s==")" || s=="[" || s=="]" || s=="{" || s=="}" || s=="|" || s==" \ " || s=="/" || s=="<" || s==">" || s=="?" || s=="!")
	{
	
		alert("Please Enter Your Phone Number Only");

		document.form.phone.value="";
		document.form.phone.focus();
		return false;
	}
	return true;
}
function cnum5()
{
s=document.form.mobile.value
s=s.substring(s.length-1);

if(s=="A" || s=="B" || s=="C" || s=="D" || s=="E" || s=="F" || s=="G" || s=="H" || s=="I" || s=="J" || s=="K" || s=="L" || s=="M" || s=="N" || s=="O" || s=="P" || s=="Q" || s=="R" || s=="S" || s=="T" || s=="U" || s=="V" || s=="W" || s=="X" || s=="Y" || s=="Z" || s=="a" || s=="b" || s=="c" || s=="d" || s=="e" || s=="f" || s=="g" || s=="h" || s=="i" || s=="j" || s=="k" || s=="l" || s=="m" || s=="n" || s=="o" || s=="p" || s=="q" || s=="r" || s=="s" || s=="t" || s=="u" || s=="v" || s=="w" || s=="x" || s=="y" || s=="z" || s==" " || s=="`" || s=="~" || s=="@" || s=="#" || s=="$" || s=="%" || s=="^" || s=="&" || s=="*" || s=="(" || s==")" || s=="[" || s=="]" || s=="{" || s=="}" || s=="|" || s==" \ " || s=="/" || s=="<" || s==">" || s=="?" || s=="!")
	{
	
		alert("Please Enter Your Mobile Number");
		document.form.mobile.value="";
		document.form.mobile.focus();
		return false;
	}
	return true;
}
function cnum6()
{
s=document.form.productname.value
s=s.substring(s.length-1);
if(s==" " || s=="`" || s=="~" || s=="@" || s=="#" || s=="$" || s=="%" || s=="^" || s=="&" || s=="*" || s=="(" || s==")" || s=="["   || s=="]" || s=="{" || s=="}" || s=="|" || s==" \ " || s=="/" || s=="<" || s==">" || s=="?" || s=="!")
	{
	
		alert("Dont Use Special Characters");
		document.form.productname.value="";
		document.form.productname.focus();
		return false;
	}
	return true;
}
function cnum7()
{
s=document.form.message.value
s=s.substring(s.length-1);
if(s==" " || s=="`" || s=="~" || s=="@" || s=="#" || s=="$" || s=="%" || s=="^" || s=="&" || s=="*" || s=="(" || s==")" || s=="["   || s=="]" || s=="{" || s=="}" || s=="|" || s==" \ " || s=="/" || s=="<" || s==">" || s=="?" || s=="!")
	{
	
		alert("Dont Use Special Characters");
		document.form.message.value="";
		document.form.message.focus();
		return false;
	}
	return true;
}
function va()
{
if(document.form.name.value=="")
{
alert("Please Enter The Name");
document.form.name.focus();
return false;
}


if(document.form.select1.value=="")
{
alert("Please Select any one of Product The Name");
document.form.select1.focus();
return false;
}
if(document.form.mobile.value=="")
{
alert("Please Enter The mobile Number");
document.form.mobile.focus();
return false;
}

if(document.form.email.value=="")
{
alert("Please Enter Email Id");
document.form.email.focus();
return false;
}
if(document.form.email.value == "")
		{
		alert("Please Enter Correct Email-ID")
		document.form.email.focus();
		return false;
		}
		if (document.form.email.value.indexOf("@") == "-1" || document.form.email.value.indexOf(".") == "-1")
		{
		alert("Please Enter Correct Email-ID");
		document.form.email.focus();
		document.form.email.value = '';
		chk1=true;
		return false;
		}
     str=document.form.email.value
	    var at="@"
		var dot="."
		var lat=str.indexOf(at)
		var lstr=str.length
		var ldot=str.indexOf(dot)
		if (str.indexOf(at)==-1){
		   alert("Invalid E-mail ID")
		   return false
		}

		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   alert("Invalid E-mail ID")
		   return false
		}

		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    alert("Invalid E-mail ID")
		    return false
		}

		 if (str.indexOf(at,(lat+1))!=-1){
		    alert("Invalid E-mail ID")
		    return false
		 }

		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    alert("Invalid E-mail ID")
		    return false
		 }

		 if (str.indexOf(dot,(lat+2))==-1){
		    alert("Invalid E-mail ID")
		    return false
		 }
		
		 if (str.indexOf(" ")!=-1){
		    alert("Invalid E-mail ID")
		    return false
		 }

 		 return true;					
	}

</script>
<style type="text/css">
.color {
	color: #F00;
}

</style>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-24002622-66', 'auto');
  ga('send', 'pageview');

</script>
<!-- Global site tag (gtag.js) - Google Analytics --> <script async src="https://www.googletagmanager.com/gtag/js?id=G-NCDJP3PS2Y"></script> <script> window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'G-NCDJP3PS2Y'); </script>                                                                     <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-131352750-4"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-131352750-4');
</script>
</head>           


</html>
